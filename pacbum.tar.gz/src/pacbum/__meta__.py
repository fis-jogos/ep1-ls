# Automatically created. Please do not edit.
__version__ = '0.1.1'
__author__ = 'Lucas S. Souza'
