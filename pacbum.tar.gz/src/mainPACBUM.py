#! /usr/bin/env python
from menuPacBum import *

#inicia o programa .
pygame.init()

mainMenu()



