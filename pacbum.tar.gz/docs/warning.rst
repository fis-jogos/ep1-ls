.. warning:: Beta software
    You are using a software that has not reached a stable version yet. Please
    beware that interfaces might change, APIs might disappear and general
    breakage can occur before *1.0*.

    If you plan to use this software for something important, please read the
    roadmap, and the issue tracker in Github. If you are unsure about the
    future of this project, please talk to the developers, or (better yet) get
    involved with the development of PacBum!