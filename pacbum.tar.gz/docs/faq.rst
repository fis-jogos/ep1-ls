==========================
Frequently asked questions
==========================

Usage
=====

Why is this file empty?
-----------------------

Because it was created automatically by python-boilerplate__ and the package
author is too busy coding and did not provide a proper FAQ section ;-)

..: http://github.com/fabiommendes/python-boilerplate/

Concepts
========

Why do we want an automatic boilerplate?
----------------------------------------

Because time is precious and we don't want to waste it in repetitive tasks. Copy
and paste can go a long way creating a new project, but is tedious and error
prone. Python boilerplate makes it easy, simple, and beautiful.