=======
License
=======

.. include:: ../LICENSE