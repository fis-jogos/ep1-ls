PAC BUM!
--------

Lucas Soares Souza 14/0151257

	O Jogo é sobre a história de PacBum, o Senhor do Tempo, que foi traído
pelos seres da 5ª Dimensão que queriam seus poderes. PacBum agora vaga perido 
na linha temporal de um planeta chamado Terra.

	A primeira fase implementada possui duas bases com um certo coeficiente
de atrito. Para que a força de atrito não fique tão grande utilizou-se uma força
maxima de atrito. No caso "4".
	As telas de batalha possuem valores físicos variados pois é uma Zona Fan-
tasma. Então em cada uma delas a jogabilidade mudará.

	O jogo ainda não tem fim. Quando o fim for implementado, PacBum derrotará
de uma vez Zielo Flu, o comandante da quinta dimensão, e voltará para casa.


